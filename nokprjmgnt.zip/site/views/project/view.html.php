<?php
/**
* @version	$Id$
* @package	Joomla
* @subpackage	NoK-PrjMgnt
* @copyright	Copyright (c) 2017 Norbert K�min. All rights reserved.
* @license	http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE
* @author	Norbert Kuemin
* @authorEmail	momo_102@bluemail.ch
*/
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die;
class NoKPrjMgntViewProject extends JViewLegacy {
	protected $item;
	protected $pageHeading = 'COM_NOKPRJMGNT_PAGE_TITLE_DEFAULT';
	protected $paramsComponent;
	protected $paramsMenuEntry;
	protected $user;
	protected $viewAccessLevels;
	protected $canDo;

	function display($tpl = null) {
		// Init variables
		$this->state = $this->get('State');
		$this->user = JFactory::getUser();
		$app = JFactory::getApplication();
		$this->document = JFactory::getDocument();

		$uri = JFactory::getURI();
		$id = $uri->getVar('id');
		if (!empty($id)) {
			$this->item = $this->get('Item');
			$this->canDo = JHelperContent::getActions('com_nokprjmgnt','project',$id);
		} else{
			$this->canDo = JHelperContent::getActions('com_nokprjmgnt');
		}
		$this->form = $this->get('Form');
		$this->paramsComponent = $this->state->get('params');
		$menu = $app->getMenu();
		if (is_object($menu)) {
			$currentMenu = $menu->getActive();
			if (is_object($currentMenu)) {
				$this->paramsMenuEntry = $currentMenu->params;
			}
		}
		// Init document
		JFactory::getDocument()->setMetaData('robots', 'noindex, nofollow');
		parent::display($tpl);
	}
}
?>