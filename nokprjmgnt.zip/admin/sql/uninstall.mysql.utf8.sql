DROP TABLE IF EXISTS `#__nok_pm_tasks`;
DROP TABLE IF EXISTS `#__nok_pm_projects`;