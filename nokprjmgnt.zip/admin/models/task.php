<?php
/**
* @version	$Id$
* @package	Joomla
* @subpackage	NoK-PrjMgnt
* @copyright	Copyright (c) 2017 Norbert Kümin. All rights reserved.
* @license	http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE
* @author	Norbert Kuemin
* @authorEmail	momo_102@bluemail.ch
*/

defined('_JEXEC') or die;

class NoKPrjMgntModelTask extends JModelAdmin {
	protected $text_prefix = 'com_nokprjmgnt';
	public $typeAlias = 'com_nokprjmgnt.task';

	/**
	 * Method to test whether a record can be deleted.
	 *
	 * @param   object    $record    A record object.
	 *
	 * @return  boolean  True if allowed to delete the record. Defaults to the permission set in the component.
	 * @since   1.6
	 */
	protected function canDelete($record) {
		if (!empty($record->id)) {
			$user = JFactory::getUser();
			return $user->authorise('core.delete', $this->typeAlias.'.' . (int) $record->id);
		}
	}

	/**
	 * Method to test whether a record can have its state edited.
	 *
	 * @param   object    $record    A record object.
	 *
	 * @return  boolean  True if allowed to change the state of the record. Defaults to the permission set in the component.
	 * @since   1.6
	 */
	protected function canEditState($record) {
		$user = JFactory::getUser();
		// Check for existing article.
		if (!empty($record->id)) {
			return $user->authorise('core.edit.state', $this->typeAlias.'.' . (int) $record->id);
		} else {
			// Default to component settings if neither article nor category known.
			return parent::canEditState('com_nokprjmgnt');
		}
	}

	/**
	 * Returns a Table object, always creating it.
	 *
	 * @param   type      The table type to instantiate
	 * @param   string    A prefix for the table class name. Optional.
	 * @param   array     Configuration array for model. Optional.
	 *
	 * @return  JTable    A database object
	 */
	public function getTable($type = 'Task', $prefix = 'NoKPrjMgntTable', $config = array()) {
		return JTable::getInstance($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   array      $data        Data for the form.
	 * @param   boolean    $loadData    True if the form is to load its own data (default case), false if not.
	 *
	 * @return  mixed  A JForm object on success, false on failure
	 * @since   1.6
	 */
	public function getForm($data = array(), $loadData = true) {
		// Get the form.
		$form = $this->loadForm($this->typeAlias, 'task', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form)) { return false; }
		return $form;
	}

	/**
	 * Method to get a single record.
	 *
	 * @param   integer      $pk        The id of the primary key.
	 *
	 * @return  JObject|boolean  Object on success, false on failure.
	 * @since   12.2
	 */
	public function getItem($pk = null) {
		$item = parent::getItem($pk);
		$item->assign_user_ids = explode(',',$item->assign_user_ids);
		return $item;
	}
	
	/**
	 * Method to save the form data.
	 *
	 * @param   array      $data        The form data.
	 *
	 * @return  boolean  True on success, false on failure.
	 * @since   12.2
	 */
	public function save($data) {
		if (is_array($data['assign_user_ids'])) {
			$data['assign_user_ids'] = implode(',',$data['assign_user_ids']);
		}
		return parent::save($data);
	}
	
	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return  mixed  The data for the form.
	 * @since   1.6
	 */
	protected function loadFormData() {
		// Check the session for previously entered form data.
		$app = JFactory::getApplication();
		$data = $app->getUserState('com_nokprjmgnt.edit.task.data', array());
		if (empty($data)) {
			$data = $this->getItem();
		}
		$this->preprocessData('com_nokprjmgnt.task', $data);
		return $data;
	}

	/**
	 * Custom clean the cache of com_content and content modules
	 *
	 * @since   1.6
	 */
	protected function cleanCache($group = null, $client_id = 0) {
		parent::cleanCache('com_nokprjmgnt');
	}
}
?>